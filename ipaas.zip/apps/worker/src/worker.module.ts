export class WorkerModule {}
