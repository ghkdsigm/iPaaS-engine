export type CommandResponseDto = any;
