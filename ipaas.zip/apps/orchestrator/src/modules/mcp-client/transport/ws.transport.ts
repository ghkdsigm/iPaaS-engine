export class WsTransport { /* placeholder */ }
