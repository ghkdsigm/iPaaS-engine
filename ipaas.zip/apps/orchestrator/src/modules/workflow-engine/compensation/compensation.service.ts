export class CompensationService { /* placeholder */ }
