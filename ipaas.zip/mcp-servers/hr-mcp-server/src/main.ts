export function main() { /* placeholder */ }
