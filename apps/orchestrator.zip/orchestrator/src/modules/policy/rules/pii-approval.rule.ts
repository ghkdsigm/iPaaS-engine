export function piiApprovalRule(spec: any) {
  const piiTokens = spec?.piiTokens;

  const hasAnyPiiToken =
    Array.isArray(piiTokens) ? piiTokens.length > 0 : typeof piiTokens === "string" ? piiTokens.length > 0 : false;

  const hasBank =
    !!spec?.entities?.bankAccountToken ||
    !!spec?.piiTokens?.bankAccount ||
    (Array.isArray(piiTokens) && piiTokens.some((t) => typeof t === "string" && t.includes("-")));

  const hasSalary = typeof spec?.entities?.salaryWon === "number";

  const payrollAmount = Array.isArray(spec?.events)
    ? spec.events.some((e: any) => e?.type === "payroll.pay" && typeof e?.slots?.amountWon === "number")
    : false;

  if (hasAnyPiiToken || hasBank || hasSalary || payrollAmount) {
    return { needsApproval: true, reason: "PII/급여 정보 포함" };
  }

  return { needsApproval: false };
}
